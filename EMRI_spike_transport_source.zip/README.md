# Redistribution of dark matter by repeated extreme mass-ratio inspirals

Editable source of the 25 November 2026 group discussion draft. Open `main.tex` to edit the article. The bibliography is included as TeX and the four figures are supplied as PDFs.

## Typeset the paper

From this directory, use TeX Live with REVTeX 4.2 installed.

~~~sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
~~~

The output is `main.pdf`. All section, figure, equation and literature references resolve on the second pass.

## Reproduce the figures

Python 3, NumPy, SciPy and Matplotlib are sufficient to redraw these four figures from the plots' input arrays.

~~~sh
python data/make_geometry.py
python data/make_profiles.py
python data/endpoint_budget.py --plot-only
~~~

`data/plotted_histories.csv.gz` contains the 100 individual realizations in each of the four host–population combinations. It preserves the history index, realized number of EMRIs, shell center, reference and final densities, and their ratio. The full ordered sequences, original rates and numerical operators are in the companion file **EMRI_transport_numerics.zip**. The instructions in `REPRODUCE.md` apply from the root of that numerical archive. They identify the external catalogue and radiation-flux software, distinguish the rerun diagnostics from the archived calculations, and give their precision checks.
