"""Reintegrate historical EMRI tracks and test the local rate of approach to the separatrix.

Run with FEW's PN5 scalar flux functions installed, or use the Python interpreter
matching an older FEW binary and supply --dso /absolute/path/to/pyInspiral.so.
The positional argument is the directory containing track_ep*.npz.
"""
import argparse
import csv
import ctypes
from pathlib import Path

import numpy as np
from scipy.integrate import quad, solve_ivp


def flux_functions(dso):
    if dso is None:
        from few.trajectory.ode.pn5 import dEdt8H_5PNe10, dLdt8H_5PNe10
        return dEdt8H_5PNe10, dLdt8H_5PNe10
    lib = ctypes.CDLL(str(dso))
    functions = []
    for key in ('E', 'L'):
        fn = getattr(lib, f'_Z13d{key}dt8H_5PNe10ddddii')
        fn.argtypes = [ctypes.c_double] * 4 + [ctypes.c_int] * 2
        fn.restype = ctypes.c_double
        functions.append(fn)
    return functions


def motion(p, e, functions):
    """Return energy and signed rates of p, e and E per unit mass ratio."""
    A = (p-2)**2 - 4*e**2
    B = p-3-e**2
    energy = np.sqrt(A/(p*B))
    angular_momentum = p/np.sqrt(B)
    Ep = 0.5*energy*(2*(p-2)/A - 1/p - 1/B)
    Ee = energy*e*(1/B - 4/A)
    Lp = angular_momentum*(1/p - 0.5/B)
    Le = angular_momentum*e/B
    J = -energy*angular_momentum*e*((p-6)**2-4*e**2)/(2*p*A*B)
    dE, dL = [f(1.e-9, p, e, 1., 10, 10) for f in functions]
    return energy, (Le*dE-Ee*dL)/J, (Ep*dL-Lp*dE)/J, dE


def radial_period(p, e):
    A = (p-2)**2-4*e**2
    def dt_dchi(chi):
        z = e*np.cos(chi)
        return p**2*np.sqrt(A/(p-6-2*z))/((p-2-2*z)*(1+z)**2)
    return 2*quad(dt_dchi, 0., np.pi, epsrel=1e-9, epsabs=0.)[0]


def check(path, functions, order):
    with np.load(path) as stored:
        a, p, e, t = [stored[k] for k in ('a','p','e','t')]
        q_gc = float(stored['q'])
    ep = e[-1]
    def slope(loga, z):
        ec = -np.expm1(z[0])
        pc = np.exp(loga+z[0])*(1+ec)
        _, pd, ed, _ = motion(pc, ec, functions)
        return [-ed/(np.exp(z[0])*pd/pc + 2*ec*ed/(1+ec))]
    solution = solve_ivp(slope, (np.log(a[-1]),np.log(a[0])), [np.log1p(-ep)],
                         method='DOP853', dense_output=True, rtol=1.5e-12,
                         atol=2e-14, max_step=.025)
    if not solution.success:
        raise RuntimeError(solution.message)
    actual_e = -np.expm1(solution.sol(np.log(a))[0])
    exact_error = np.abs(actual_e-e)
    edges = np.log(a[::2])
    upper, lower = edges[:-1], edges[1:]
    nodes, weights = np.polynomial.legendre.leggauss(order)
    x = (upper+lower)[:,None]/2 + (upper-lower)[:,None]*nodes/2
    ecc = -np.expm1(solution.sol(x.ravel())[0])
    pp = np.exp(x.ravel())*(1-ecc)*(1+ecc)
    _, pd, ed, _ = np.array([motion(i,j,functions) for i,j in zip(pp,ecc)]).T
    jac = -1/(q_gc*(pd/pp + 2*ecc*ed/((1-ecc)*(1+ecc))))
    tm = (upper-lower)/2*(jac.reshape(x.shape) @ weights)
    old = np.diff(t[::2])
    if not np.all(tm>0):
        raise ValueError('Non-positive forward residence time')
    periods = np.array([radial_period(i,j) for i,j in zip(p,e)])
    energy,pd,ed,Ed = np.array([motion(i,j,functions) for i,j in zip(p,e)]).T
    row = dict(e_star=ep, max_abs_e_error=exact_error.max(),
               max_rel_rp_error=(exact_error/(1-e)).max(),
               rel_total_clock_error=old.sum()/tm.sum()-1,
               max_abs_rel_window_clock_error=np.max(np.abs(old/tm-1)))
    for host,q in [('gc',q_gc),('low',10/3.e5)]:
        gap = periods*q*np.abs(pd-2*ed)/(p-6-2*e)
        binding = periods*q*np.abs(Ed)/(1-energy)
        row['eta_s_endpoint_'+host]=gap[-1]
        row['eta_s_max_'+host]=gap.max()
        row['frac_binding_change_max_'+host]=binding.max()
    return row


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tracks', type=Path)
    parser.add_argument('--dso', type=Path)
    parser.add_argument('--order', type=int, default=12)
    parser.add_argument('--output', type=Path, default=Path('binary_validation.csv'))
    args=parser.parse_args()
    fs=flux_functions(args.dso)
    rows=[check(path,fs,args.order) for path in sorted(args.tracks.glob('track_ep*.npz'))]
    if len(rows)!=11:
        raise ValueError('Expected eleven input tracks')
    with args.output.open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
