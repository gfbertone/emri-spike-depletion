"""Reconstruct endpoint flow from the finite-volume scattering operators.

The optional operator cache uses the generator-byte hash used by population_profiles.py.
Example: python endpoint_budget.py --root /path/to/unpacked_source --cache /path/to/ops
Run with --plot-only to reproduce the figure from the released thin files.
"""
import argparse
import csv
import hashlib
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def csv_rows(path):
    with path.open() as reader:
        return list(csv.DictReader(reader))


def save_csv(path, rows):
    with path.open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def compute(root, cache, out):
    from scipy.linalg import expm
    from scipy.sparse import load_npz

    research = root / 'emri_research_work'
    catalogue = root / 'emri_population_work/profiles/catalogue'
    projections = np.load(research / 'profiles/projection_fine.npz')
    F = projections['shell_frac']
    radii = projections['r']
    rows, totals, maps = [], [], {}
    for host, levels in [('gc', (270, 330)), ('low', (270,))]:
        cells = np.load(research / f'transport/transport_{host}_fine.npz')
        ref = [r for r in csv_rows(catalogue / f'mean_profiles_{host}.csv')
               if r['model'] == 'Best' and r['history_law'] == 'fixed_N']
        initial = sorted([r for r in ref if float(r['count_parameter']) == 0],
                         key=lambda row: int(row['shell']))
        # Proper shell volumes scale as M^3 on the dimensionless r/M grid.
        mass = 4.3e6 if host == 'gc' else 3.e5
        vol = projections['vol_pc3'] * (mass/4.3e6)**3
        w = projections['cell_mass_msun'].copy()
        norms = np.array([float(r['rho0']) for r in initial]) * vol / (w @ F)
        np.testing.assert_allclose(norms, np.full(len(norms), norms[0]), rtol=5e-11)
        w *= norms[0]
        Bi = w @ F
        p = np.array([float(r['probability']) for r in csv_rows(catalogue / f'class_probabilities_{host}.csv') if r['model'] == 'Best'])
        np.testing.assert_allclose(p.sum(), 1, atol=3e-14)
        T = np.zeros((len(w)+3, len(w)+3))
        for c in np.flatnonzero(p):
            Q = load_npz(research / f'transport/gen_{host}_fine_c{c:02}.npz').toarray()
            key = hashlib.sha256(Q.tobytes()).hexdigest()[:12]
            path = cache / f'{host}_fine_{c:02}_{key}.npy' if cache else None
            Tk = np.load(path) if path and path.exists() else expm(Q)
            T += p[c]*Tk
        np.testing.assert_allclose(T.sum(0), 1, atol=2e-11, rtol=0)
        np.testing.assert_allclose(T[-3:,-3:], np.eye(3), atol=3e-14)
        # Forward mass and independent backwards fate probabilities, plus one terminal
        # shell reward. Latter validates the orientation and the forward projection.
        fwd = np.r_[w, np.zeros(3)]
        adj = np.zeros((len(T), 5))
        adj[-3:, :3] = np.eye(3)
        adj[:-3, 3] = 1
        adj[:-3, 4] = F[:,6]
        for n in range(1, max(levels)+1):
            fwd = T @ fwd
            adj = T.T @ adj
            if n not in levels:
                continue
            np.testing.assert_allclose(fwd.sum(), w.sum(), rtol=2e-10)
            np.testing.assert_allclose(adj[:,:4].sum(1), 1, rtol=2e-10)
            survival = (fwd[:-3] @ F) / Bi
            absorbed = (F.T @ (w[:,None]*adj[:-3,:3])) / Bi[:,None]
            # Survivor redistribution: old shell contribution of final bound survivors,
            # minus their final shell contribution. A negative term is net inflow.
            redistrib = ((w*adj[:-3,3]) @ F - fwd[:-3] @ F) / Bi
            error = 1-survival - absorbed.sum(1)-redistrib
            assert max(abs(error)) < 3e-10
            np.testing.assert_allclose(w @ adj[:-3,4], survival[6]*Bi[6],rtol=2e-10)
            np.testing.assert_allclose(w @ adj[:-3,:3], fwd[-3:], rtol=2e-10, atol=1e-14)
            check = sorted([r for r in ref if float(r['count_parameter']) == n],key=lambda row: int(row['shell']))
            if check: np.testing.assert_allclose([float(r['survival']) for r in check], survival,rtol=2e-10)
            for j,radius in enumerate(radii):
                rows.append(dict(host=host,N=n,r_over_M=radius,initial_shell_mass_msun=Bi[j],
                    survival=survival[j],loss=1-survival[j],capture=absorbed[j,0],
                    escape=absorbed[j,1],outer_bound=absorbed[j,2],
                    net_survivor_redistribution=redistrib[j],closure_residual=error[j]))
            totals.append(dict(host=host,N=n,initial_msun=w.sum(),bound_on_grid_msun=fwd[:-3].sum(),
                capture_msun=fwd[-3],escape_msun=fwd[-2],outer_bound_msun=fwd[-1],
                mass_relative_error=fwd.sum()/w.sum()-1,max_shell_closure_abs=max(abs(error))))
            maps[f'{host}_{n}_w_final']=fwd[:-3].reshape(len(cells['x']),len(cells['y']))
        maps[f'{host}_w_initial']=w.reshape(len(cells['x']),len(cells['y']))
        for axis in ['x_edges','y_edges']: maps[f'{host}_{axis}']=cells[axis]
    save_csv(out/'endpoint_budget.csv', rows)
    save_csv(out/'endpoint_domain_mass.csv', totals)
    np.savez_compressed(out/'endpoint_cells.npz', **maps)


def make_plot(out, dest):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        from matplotlib.colors import TwoSlopeNorm
    except ImportError:  # Matplotlib 3.1 name
        from matplotlib.colors import DivergingNorm as TwoSlopeNorm
    from matplotlib.ticker import MaxNLocator
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import Normalize
    from matplotlib.gridspec import GridSpec

    z = np.load(out/'endpoint_cells.npz')
    w, wn = z['gc_w_initial'], z['gc_270_w_final']
    field = np.ma.masked_where((w<=0)|(wn<=0), np.log10(wn/w))
    quantiles = np.percentile(field.compressed(),[2,98])
    # Make the center of the diverging map equal to the unperturbed cell mass.
    vmin = np.floor(min(quantiles[0],-.1)*5)/5
    vmax = np.ceil(max(quantiles[1],.1)*5)/5
    if vmax < .2: vmax=.2
    norm=TwoSlopeNorm(vmin=vmin,vcenter=0,vmax=vmax)
    data = [r for r in csv_rows(out/'endpoint_budget.csv') if r['host']=='gc' and int(r['N'])==270]
    A=lambda name: np.array([float(r[name]) for r in data])
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':9.3,
            'axes.titlesize':10,'xtick.labelsize':8,'ytick.labelsize':8,
            'pdf.fonttype':42,'mathtext.fontset':'dejavusans','axes.linewidth':.65})
    fig=plt.figure(figsize=(7.05,3.72)); gs=GridSpec(1,2,figure=fig,width_ratios=[1,1],
                      left=.078,right=.978,bottom=.28,top=.91,wspace=.35)
    ax=fig.add_subplot(gs[0]); bx=fig.add_subplot(gs[1])
    im=ax.pcolormesh(z['gc_x_edges'],z['gc_y_edges'],field.T,cmap='RdBu',norm=norm,
                     rasterized=True,shading='flat')
    ax.set_xlabel(r'$\ln(1-E)$');ax.set_ylabel(r'$(L-L_{\rm cap})/(L_{\rm circ}-L_{\rm cap})$')
    ax.set_title('(a) Bound-orbit population',loc='left')
    ax.xaxis.set_major_locator(MaxNLocator(6));ax.set_ylim(0,1)
    # Inset horizontal color scale below the plotting area; no interpolation of cells.
    cax=fig.add_axes([.101,.049,.30,.023])
    vals=np.unique(np.array([vmin,-1,-.5,0,vmax/2,vmax]))
    scale=ScalarMappable(norm=Normalize(-1,1),cmap=im.cmap)
    scale.set_array([])
    positions=np.where(vals<0,vals/abs(vmin),vals/vmax)
    bar=fig.colorbar(scale,cax=cax,orientation='horizontal',extend='min',ticks=positions)
    bar.ax.set_xticklabels([('%g' % v).replace('-', '−') for v in vals])
    bar.ax.tick_params(labelsize=7,length=2,pad=1)
    bar.ax.set_title(r'$\log_{10}(w_{270}/w_0)$',fontsize=8,pad=3)
    x=A('r_over_M')
    for name,lbl,col,style,lw in [('capture','Capture','#ae3425','--',1.4),('escape','Escape','#067671','-.',1.4),
          ('outer_bound','Bound overflow','#795a98',':',1.8),
          ('net_survivor_redistribution','Redistribution','#346399','-',1.4)]:
        bx.plot(x,A(name),label=lbl,color=col,ls=style,lw=lw)
    bx.axhline(0,color='.55',linewidth=.55,zorder=0)
    bx.set_xscale('log');bx.set_xlim(x[0],x[-1]);bx.set_xticks([5,10,30,100,250])
    bx.set_xticklabels(['5','10','30','100','250'])
    bx.set_xlabel(r'$r\,c^2/(G M_\bullet)$');bx.set_ylabel('Fraction of initial shell density')
    bx.set_title('(b) Contributions to the shell loss',loc='left')
    bx.legend(frameon=False,fontsize=7,loc='best',handlelength=2.3,labelspacing=.28,
              borderaxespad=.35)
    bx.grid(axis='y',color='.9',lw=.5)
    for a in (ax,bx):a.tick_params(width=.65,length=3)
    fig.savefig(dest,bbox_inches='tight',pad_inches=.045)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=HERE.parents[1])
    parser.add_argument('--cache',type=Path)
    parser.add_argument('--output',type=Path,default=HERE)
    parser.add_argument('--figure',type=Path,default=HERE.parent/'figures/phase_space.pdf')
    parser.add_argument('--plot-only',action='store_true')
    args=parser.parse_args()
    if not args.plot_only: compute(args.root,args.cache,args.output)
    make_plot(args.output,args.figure)

if __name__=='__main__': main()
