"""Draw Schwarzschild bound-orbit geometry from the geodesic equations.

Run with Python, NumPy, and Matplotlib. The default output is the manuscript
figure beside this script's data directory. Supply --output to select a path.
"""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.ticker import FormatStrFormatter, NullFormatter
import numpy as np

TEAL = "#176c6a"
TEAL_FILL = "#d8ece8"
RUST = "#99482d"
RUST_FILL = "#f4e4db"
INK = "#172932"
SLATE = "#4e6069"


def circular_branches(energy):
    """Critical angular momenta at fixed total specific energy  sqrt(8/9)<E<1."""
    d = 4 - 3 * energy**2 + energy * np.sqrt(np.maximum(9 * energy**2 - 8, 0))
    unstable = 8 / d
    stable = d / (2 * (1 - energy**2))
    return unstable / np.sqrt(unstable - 3), stable / np.sqrt(stable - 3)


def potential(x, angular_momentum):
    """V_eff such that (dx/dtau)^2=E^2 - V_eff."""
    return (1 - 2 / x) * (1 + (angular_momentum / x)**2)


def draw(out):
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8.2, "mathtext.fontset": "dejavusans",
        "axes.labelsize": 8.3, "axes.titlesize": 9, "axes.titleweight": "semibold",
        "axes.labelcolor": INK, "axes.edgecolor": SLATE,
        "xtick.color": SLATE, "ytick.color": SLATE, "text.color": INK,
        "axes.linewidth": .65, "xtick.major.width": .65, "ytick.major.width": .65,
        "xtick.major.size": 3, "ytick.major.size": 3,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    energy, angular = .98, 4.10
    roots = np.sort(np.roots([energy**2 - 1, 2, -angular**2, 2 * angular**2]))
    assert np.isreal(roots).all() and roots[0] > 2
    inner, peri, apo = roots.real
    lower, upper = circular_branches(energy)
    assert lower < angular < upper
    assert np.max(np.abs(potential(roots, angular) - energy**2)) < 2e-13
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.05, 2.65))
    fig.subplots_adjust(left=.075, right=.985, bottom=.2, top=.87, wspace=.30)

    isco_energy = np.sqrt(8 / 9)
    energies = np.linspace(isco_energy, 1 - 1e-7, 1800)
    loss, circular = circular_branches(energies)
    left.fill_between(energies, loss, circular, color=TEAL_FILL)
    left.fill_between(energies, 3.15, loss, color=RUST_FILL)
    left.plot(energies, circular, lw=1.45, color=TEAL, label="Stable circular orbit")
    left.plot(energies, loss, lw=1.3, ls="--", color=RUST, label="Capture boundary")
    left.scatter([isco_energy], [np.sqrt(12)], color=INK, s=11, zorder=5)
    left.annotate("ISCO", (isco_energy, np.sqrt(12)), xytext=(.948, 3.99),
                  fontsize=7.1, arrowprops={"arrowstyle": "-", "color": SLATE, "lw": .65})
    left.text(.9905, 4.98, "Exterior\nbound orbits", color=TEAL, ha="center", va="center")
    left.text(.9805, 3.50, "Loss cone", color=RUST, ha="center", va="center")
    left.plot(energy, angular, "o", color=INK, markeredgecolor="white", mew=.65, ms=5.0)
    left.text(energy+.0014, angular+.012, "Example", fontsize=7.1, va="center")
    left.legend(loc="upper left", frameon=False, fontsize=7.1, handlelength=2.3)
    left.set(xlim=(.941, 1), ylim=(3.18, 5.85), xlabel="Specific energy, $E$",
             ylabel="Specific angular momentum, $L$")
    left.set_xticks([.95, .96, .97, .98, .99, 1.00])
    left.set_yticks([3.5, 4, 4.5, 5, 5.5])
    left.set_title("(a)  Allowed exterior orbits", loc="left")

    x = np.unique(np.r_[np.geomspace(2.0, 80, 1800), roots])
    v = potential(x, angular)
    right.fill_between(x, v, energy**2, where=x<=inner, color=RUST_FILL)
    right.fill_between(x, v, energy**2, where=(x>=peri) & (x<=apo), color=TEAL_FILL)
    right.plot(x, v, color=INK, lw=1.5)
    right.axhline(energy**2, color=SLATE, ls=(0, (4, 2.7)), lw=.9)
    right.scatter(roots, np.repeat(energy**2, 3), color=INK, edgecolor="white", linewidth=.45,
                  s=18, zorder=4)
    right.text(63, energy**2-.004, "$E^2$", color=SLATE, fontsize=8, ha="center", va="top")
    for x0, s, offset in [(inner, "$x_1$", (-8, 7)), (peri, "$x_{\\rm p}$", (4, 7)),
                           (apo, "$x_{\\rm a}$", (-4, 8))]:
        right.annotate(s, (x0, energy**2), xytext=offset, textcoords="offset points",
                       ha="center", fontsize=8)
    right.text(4.14, .990, "Barrier", ha="center", color=SLATE, fontsize=7.2)
    right.annotate("Inner branch", (2.56, .901), xytext=(4.1, .894), color=RUST,
                   va="center", fontsize=7.2,
                   arrowprops={"arrowstyle": "-", "color": RUST, "lw": .65})
    right.text(15.4, .944, "Bound orbit", color=TEAL, fontsize=7.5, ha="center")
    right.set(xscale="log", xlim=(2, 80), ylim=(.88, 1.044),
              xlabel="Areal radius, $x=r/r_{\\rm g}$", ylabel="Effective potential, $V_{\\rm eff}$")
    right.set_yticks([.88, .92, .96, 1., 1.04])
    right.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    right.set_xticks([2, 3, 5, 10, 20, 40, 80])
    right.xaxis.set_major_formatter(FormatStrFormatter("%g"))
    right.xaxis.set_minor_formatter(NullFormatter())
    right.set_title("(b)  Radial motion at $E=0.98$, $L=4.10$", loc="left")
    for ax in (left, right):
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, metadata={"Creator": "Schwarzschild geodesics; make_geometry.py"})
    plt.close(fig)
    print("Turning radii:", *[f"{r:.6f}" for r in roots])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    default_output = Path(__file__).resolve().parents[1] / "figures" / "geodesic_geometry.pdf"
    parser.add_argument("--output", type=Path, default=default_output)
    draw(parser.parse_args().output)
