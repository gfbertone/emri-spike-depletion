"""Redraw the two population figures from the supplied numerical tables."""
import csv
import gzip
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator, NullFormatter
from matplotlib.lines import Line2D

here = Path(__file__).resolve().parent
figdir = here.parent/'figures'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.linewidth':0.55,
                     'xtick.major.width':0.55,'ytick.major.width':0.55,
                     'xtick.minor.width':0.4,'ytick.minor.width':0.4,
                     'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
with gzip.open(here/'plotted_histories.csv.gz','rt') as f:
    histories=list(csv.DictReader(f))
with (here/'fixed_count_profiles.csv').open() as f:
    fixed=list(csv.DictReader(f))

def radius(ax):
    ax.set_xlim(4.2,300)
    ax.set_xticks([5,10,30,100,250],['5','10','30','100','250'])
    ax.set_xlabel(r'$r/r_{\rm g}$',labelpad=1)
    ax.tick_params(which='major',length=3,pad=2)
    ax.tick_params(which='minor',length=1.7)
    ax.xaxis.set_minor_formatter(NullFormatter())

def histories_figure():
    fig, axes=plt.subplots(2,4,figsize=(7.02,3.78),sharex=True,sharey='row')
    fig.subplots_adjust(left=.084,right=.985,bottom=.115,top=.845,wspace=.14,hspace=.11)
    for col,(host,pop) in enumerate([('gc','catalogue'),('gc','maintained'),('low','catalogue'),('low','maintained')]):
        rows=[r for r in histories if r['host']==host and r['population']==pop]
        rows.sort(key=lambda r:(int(r['history']),int(r['shell'])))
        assert len(rows)==1700
        r=np.array([float(v['r_mid']) for v in rows[:17]])
        rho0=np.array([float(v['rho0']) for v in rows[:17]])
        ss=np.array([float(v['survival']) for v in rows]).reshape(100,17)
        assert np.all(ss>0) and np.allclose([[float(v['rho']) for v in rows[i:i+17]] for i in range(0,1700,17)],ss*rho0)
        color='#176578' if pop=='catalogue' else '#a04d24'
        for row,(matrix,base) in enumerate([(ss*rho0,rho0),(ss,np.ones_like(r))]):
            ax=axes[row,col]
            ax.set_xscale('log')
            ax.set_yscale('log')
            ax.plot(r,matrix.T,color=color,alpha=.085,lw=.48,rasterized=True)
            ax.plot(r,np.median(matrix,axis=0),color=color,lw=1.65)
            ax.plot(r,base,color='#272727',ls='--',lw=.86)
            ax.grid(which='major',axis='y',lw=.35,color='#d5d7d9')
            radius(ax)
            if row==0:
                ax.set_xlabel('')
                ax.set_title('Catalogue' if pop=='catalogue' else 'Maintained cusp',fontsize=8.3,pad=4)
        if col in (0,2):
            ttl= r'Galactic Centre  ($\Lambda=330$)' if col==0 else r'Light host  ($\Lambda=80$)'
            x=(axes[0,col].get_position().x0+axes[0,col+1].get_position().x1)/2
            fig.text(x,.962,ttl,weight='bold',ha='center',fontsize=9.1)
    axes[0,0].set_ylabel(r'$\rho\ [M_\odot\,{\rm pc}^{-3}]$')
    axes[1,0].set_ylabel(r'$\rho/\rho_0$')
    for ax in axes[0,:]:
        ax.yaxis.set_major_locator(LogLocator(base=10,numticks=6))
    for ax in axes[1,:]:
        ax.yaxis.set_major_locator(LogLocator(base=10,numticks=5))
    fig.savefig(figdir/'histories.pdf',dpi=320)
    plt.close(fig)

def fixed_figure():
    fig,axes=plt.subplots(1,2,figsize=(3.41,2.18),sharey=True)
    fig.subplots_adjust(left=.155,right=.99,bottom=.28,top=.89,wspace=.085)
    models=[('Best','Catalogue','#1b6976','-'),('Finite_volume_burst','Steady flux','#36845c','--'),('Direct_first_passage','Excursions','#a66a22','-.'),('Rom','Rom','#83618b','-'),('Babak','Babak','#565b67',':')]
    for a,h in zip(axes,('gc','low')):
        for code,l,c,s in models:
            rows=[v for v in fixed if v['model']==code and v['host']==h]
            a.loglog([float(v['r_mid']) for v in rows],[float(v['survival']) for v in rows],ls=s,color=c,lw=1.2)
        radius(a)
        a.set_xticks([5,30,200],['5','30','200'])
        a.set_ylim(1e-6,1.2)
        a.set_title('Galactic Centre' if h=='gc' else 'Light host',fontsize=8,pad=3)
        a.grid(axis='y',lw=.35,color='#ddd')
    axes[0].set_ylabel(r'$\rho/\rho_0$',labelpad=1)
    fig.legend(handles=[Line2D([],[],color=c,ls=s,lw=1.2,label=l) for _,l,c,s in models],loc='lower center',ncol=3,fontsize=6.4,handlelength=1.8,columnspacing=.8,handletextpad=.4,frameon=False,borderpad=0)
    fig.savefig(figdir/'fixed_count.pdf')
    plt.close(fig)
if __name__=='__main__':
    histories_figure()
    fixed_figure()
