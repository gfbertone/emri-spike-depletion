"""Compare one finite-duration cold inspiral with a Poisson population of short events.

Run from the unpacked supplement, e.g.
  python emri_paper/validation/overlapping_inspirals.py . --output replay/overlapping_inspirals.csv

The incident population is the Galactic Centre maintained-cusp model. The warm
stream excludes the two tested cold classes, renormalizes the remaining weights,
and has a fixed rate of 33/Gyr. Each warm event is instantaneous. We treat each
of four equal ln(a) segments of the cold inspiral as a constant generator.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.linalg import expm
from scipy.sparse import load_npz

DATA = Path(__file__).resolve().parents[1]/"data"
TRACK_LABELS = ("0.001","0.003")
EVENT_RATE_PER_GYR = 33.0
INITIAL_CASE_COUNTS = (0,135)


def read_inputs(root):
    research = root/"emri_research_work"
    transport = research/"transport"
    nominal = [transport/f"gen_gc_c{k:02d}.npz" for k in range(11)]
    segments = [[transport/f"gen_gc_t{j}_c{k:02d}.npz" for j in range(4)]
                for k in range(2)]
    tracks = [research/"tracks"/f"track_ep{e}.npz" for e in TRACK_LABELS]
    projection = research/"profiles/projection_gc_q15.npz"
    class_input = root/"emri_population_work/profiles/tail_completion/support_completion/class_probabilities_gc.csv"
    with class_input.open() as stream:
        rows = [r for r in csv.DictReader(stream) if r["model"]=="FV_empty_support"]
    p = np.array([float(r["probability"]) for r in sorted(rows,key=lambda r:int(r["cls"]))])
    if len(p)!=11 or not np.isclose(p.sum(),1) or not p[2]>0:
        raise ValueError("Invalid maintained-cusp class distribution")
    paths = [*nominal,*segments[0],*segments[1],*tracks,projection,class_input]
    return nominal,segments,tracks,projection,p,paths


def model(root, manifest=None):
    nominal,segments,tracks,projection,p,paths = read_inputs(root)
    hashes = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest()
              for path in paths}
    if manifest is not None:
        if hashes!=json.loads(manifest.read_text())["sha256"]:
            raise ValueError("Input hashes differ from the distributed manifest")
    pr = np.load(projection)
    m,F,r = pr["cell_mass_msun"],pr["shell_frac"],pr["r"]
    w0 = np.r_[m,[0.,0.,0.]]
    eye = np.eye(len(w0))
    operators = [expm(load_npz(path).toarray()) for path in nominal]
    unconditioned = sum(pk*T for pk,T in zip(p,operators))
    warm_p = p.copy()
    warm_p[:2] = 0
    warm_p /= warm_p.sum()
    background = sum(pk*T for pk,T in zip(warm_p,operators))-eye
    inputs = np.column_stack([np.linalg.matrix_power(unconditioned,n)@w0
                              for n in INITIAL_CASE_COUNTS])
    records = []
    for k,e in enumerate(TRACK_LABELS):
        t = np.load(tracks[k])["t"]
        if len(t)!=145:
            raise ValueError("Expected 145-node logarithmic track")
        dt_gyr = np.diff(t[::36])*4.3e6*4.925490947e-6/31557600/1e9
        rates = EVENT_RATE_PER_GYR*dt_gyr
        poisson = expm(rates.sum()*background)
        # The reference gives cold evolution and the warm event stream the same clock.
        combined = inputs.copy()
        warm_before = poisson@inputs
        cold_only = inputs.copy()
        for path,mean in zip(segments[k],rates):
            A = load_npz(path).toarray()
            cold = expm(A)
            combined = expm(A+mean*background)@combined
            warm_before = cold@warm_before
            cold_only = cold@cold_only
        warm_after = poisson@cold_only
        shell = [(z[:-3].T@F)/(m@F) for z in [combined,warm_before,warm_after]]
        for i,n in enumerate(INITIAL_CASE_COUNTS):
            for j,radius in enumerate(r):
                inter,before,after = (s[i,j] for s in shell)
                records.append(dict(terminal_e=float(e),prior_N=n,radius_rg=radius,
                    expected_warm_events=rates.sum(),
                    **{f"expected_warm_quarter_{j+1}":v for j,v in enumerate(rates)},
                    survival_interleaved=inter,survival_warm_before=before,
                    survival_warm_after=after,frac_before_vs_interleaved=before/inter-1,
                    frac_after_vs_interleaved=after/inter-1))
    return records,hashes


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root",type=Path)
    parser.add_argument("--output",type=Path,default=DATA/"overlapping_inspirals.csv")
    parser.add_argument("--manifest",type=Path,default=DATA/"overlapping_inspirals_inputs.json")
    parser.add_argument("--write-manifest",action="store_true")
    args=parser.parse_args()
    records,hashes=model(args.root.resolve(),None if args.write_manifest else args.manifest)
    if args.write_manifest:
        metadata = {"case":"maintained GC cusp; independent warm marks", "rate_per_gyr":33,
                    "prior_counts":list(INITIAL_CASE_COUNTS),"cold_terminal_e":[.001,.003],
                    "cold_time_segments":"four contiguous equal intervals of log semimajor axis",
                    "rebuild_from_emri_research_work_transport":[
                        "python physical_transport.py gc",
                        *[f"python physical_transport.py gc_t{j} --classes 0,1 --part {j} --npart 4" for j in range(4)]],
                    "rebuild_coarse_projection_from_emri_research_work_profiles":
                    "python make_projection.py ../transport/transport_gc.npz ../regime projection_gc_q15.npz --order 15",
                    "sha256":hashes}
        args.manifest.write_text(json.dumps(metadata,indent=2)+"\n")
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open("w",newline="") as stream:
        output=csv.DictWriter(stream,fieldnames=records[0]);output.writeheader();output.writerows(records)
    for e in map(float,TRACK_LABELS):
        selected=[z for z in records if z["terminal_e"]==e and
                  (abs(z["radius_rg"]-20.84)<0.1 or abs(z["radius_rg"]-95.67)<0.1)]
        extremes=max((abs(z[col]),z["radius_rg"],z["prior_N"],col)
                     for z in selected for col in ("frac_before_vs_interleaved","frac_after_vs_interleaved"))
        print(f"e={e:.3g}   max fractional difference at headline radii {extremes}")
if __name__=="__main__":
    main()
