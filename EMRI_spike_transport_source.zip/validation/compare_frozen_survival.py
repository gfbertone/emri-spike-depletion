"""Test whether averaging log survival versus survival explains the difference.

Usage: python compare_frozen_survival.py /path/to/emri_research_work /path/to/emri_population_work /path/to/regime/emu/ens_60000.npz output.csv
The frozen ensemble and the population transfer solve different dynamics, so
this program tabulates the two fixed-orbit statistics and their sampling error.
"""
from pathlib import Path
import argparse,csv,json,sys
import numpy as np
from scipy.sparse import load_npz

def main():
    pa=argparse.ArgumentParser(description=__doc__);pa.add_argument('research',type=Path);pa.add_argument('population',type=Path);pa.add_argument('ensemble',type=Path);pa.add_argument('output',type=Path);args=pa.parse_args()
    sys.path.insert(0,str(args.research/'crosscheck'))
    import prepare
    init=np.load(args.ensemble);p,e,T,wm=prepare.init(init);a=p/(1-e*e)
    proposal=(wm/wm.sum(axis=1)[:,None]).mean(axis=0)
    edge=np.geomspace(4,300,18);covered=(edge[:-1]>=6)&(edge[1:]<=120);lo=edge[:-1][covered];hi=edge[1:][covered]
    def U(r):return np.arccos(np.clip((1-r/a)/e,-1,1))
    target=np.stack([init['W']*prepare.radial_times(p,e,U(x),U(y))/T for x,y in zip(lo,hi)])
    cfg=json.loads((args.population/'profiles/catalogue/config.json').read_text())
    pr=np.load(args.research/'profiles/projection_fine.npz')
    m=pr['cell_mass_msun'];F=pr['shell_frac'];cell_w=(m[:,None]*F)/(m@F)
    rows=[]
    for name in ['gc','low']:
        z=np.load(args.research/'crosscheck'/f'frozen_{name}.npz');haz=z['hazards'].sum(axis=2)
        index=z['index'];ids=z['ids'][index];w=target[:,ids]/proposal[ids]
        sink=np.stack([load_npz(args.research/'transport'/f'gen_{name}_fine_c{k:02d}.npz').toarray()[-3:,:-3] for k in range(11)])
        fix=list(csv.DictReader((args.population/'profiles/catalogue'/f'mean_profiles_{name}.csv').open()))
        for pop in ['Best','Babak','Rom']:
            spec=cfg['hosts'][name]['models'].get(pop,{})
            ps=spec.get('weights') or json.loads((args.research/'profiles/population_weights.json').read_text())[pop]
            # The independent frozen calculation uses prompt escape and primary
            # capture only. All surviving particles stay on their initial orbit.
            araw=(np.exp(-haz)@ps)**270;graw=np.exp(-270*(haz@ps))
            direct_cell=(np.asarray(ps)@np.exp(-sink[:,:2].sum(axis=1)))**270@cell_w
            all_cell=(np.asarray(ps)@np.exp(-sink.sum(axis=1)))**270@cell_w
            for i,(l,h) in enumerate(zip(lo,hi)):
                yr=np.sqrt(l*h);q=w[i];ww=q/q.sum()
                val=(ww*araw[index]).sum();vg=(ww*graw[index]).sum()
                delta=(araw[index]-val)*q/q.mean()
                se=np.sqrt(np.sum(delta.var(axis=1,ddof=1)/delta.shape[1]))/delta.shape[0]
                hit=next(s for s in fix if s['model']==pop and s['history_law']=='fixed_N' and float(s['count_parameter'])==270 and abs(float(s['r_mid'])-yr)<1e-6)
                rows.append(dict(host=name,population=pop,N=270,r_mid_M=yr,arithmetic_frozen=val,arithmetic_sampling_se=se,geometric_frozen=vg,grid_frozen_two_sinks=direct_cell[np.where(covered)[0][i]],grid_frozen_three_sinks=all_cell[np.where(covered)[0][i]],full_transport_mean=float(hit['survival'])))
    with args.output.open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0]);wr.writeheader();wr.writerows(rows)
if __name__=='__main__':main()
