"""Test the unresolved innermost slow-density interpolation in the circular phase fit.

Run python validation/inner_slow_extrapolation.py from any directory with NumPy
and SciPy installed. The compact fixture holds the four-year vacuum clock,
normalized noise weights, and five slow-density shell values per history. To
rebuild it from the full research bundle, pass --catalogue and --lisa-code.
"""
import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import brentq

DATA = Path(__file__).resolve().parents[1] / "data"
SCENARIOS = ("central", "uniform_rank97", "matched")
M = 3e5
M_SECONDS = M * 4.925490947e-6
RHOHAT = 6.67430e-11 * 1.98847e30 / 3.08567758149e16**3 * M_SECONDS**2


def make_fixture(catalogue, lisa_code, output):
    sys.path.insert(0, str(lisa_code.resolve()))
    import circular

    def clock(p0):
        x = np.linspace(1/p0, 1/6.3, 4200)
        t = cumulative_trapezoid(circular.dtau_dx_unit_q(x)*M_SECONDS*M/10, x, initial=0)
        return x, t

    start = brentq(lambda p: clock(p)[1][-1]-4*circular.YR, 6.31, 60)
    x, t = clock(start)
    om = x**1.5/M_SECONDS
    phi = cumulative_trapezoid(om, t, initial=0)
    dt = np.gradient(t)
    dt[[0,-1]] *= 0.5
    weights = dt*x*x/circular.psd(om/np.pi)
    weights /= weights.sum()
    basis = circular.nuisance_basis(t,x,phi,M,True).T
    groups = defaultdict(list)
    for file in ("histories_low.csv", "active_episode_histories_low.csv"):
        with (catalogue/file).open() as stream:
            for row in csv.DictReader(stream):
                scenario = row.get("scenario", "uniform_rank97")
                if row.get("model","Best") != "Best" or scenario not in SCENARIOS:
                    continue
                r, rho = float(row["r_mid"]),float(row["rho_slow"])
                if np.isfinite(rho) and r <= 21:
                    groups[(scenario,int(row["history"]))].append((r,rho))
    labels = sorted(groups)
    rr = np.array(sorted(groups[labels[0]]))[:,0]
    rho = np.array([np.array(sorted(groups[key]))[:,1] for key in labels])
    if len(labels) != 300 or not rr[0] > 6.3 or not rr[-1] >= start:
        raise ValueError("Expected three 100-history cohorts spanning the observing band.")
    np.savez_compressed(output, t=t, x=x, weights=weights, basis=basis,
                        radius=rr, rho=rho, scenario=[k[0] for k in labels],
                        history=[k[1] for k in labels])


def run(fixture, output):
    d = np.load(fixture)
    x,t,r = d["x"],d["t"],d["radius"]
    om = x**1.5/M_SECONDS
    sqrtw = np.sqrt(d["weights"])
    weighted_basis = d["basis"]*sqrtw[:,None]
    Q = np.linalg.qr(weighted_basis / np.linalg.norm(weighted_basis,axis=0))[0]
    thresholds = {}
    for power in (0.5,2.0,3.5,6.0):
        radii = np.r_[6.3,r]
        sample = []
        for bins in d["rho"]:
            anchors = np.r_[bins[0]*(0.3/(r[0]-6))**power,bins]
            density = np.exp(np.interp(-np.log(x),np.log(radii),np.log(anchors)))
            eps = 5*np.pi/8*10*RHOHAT*density*x**(-5.5)
            phase = 2*(om*cumulative_trapezoid(eps,t,initial=0)
                       - cumulative_trapezoid(eps*om,t,initial=0))
            signal = sqrtw*phase
            sample.append(0.1/np.linalg.norm(signal-Q@(Q.T@signal)))
        thresholds[power] = np.array(sample)
    with output.open("w",newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["scenario","power","n","median_A3","A100_crossings",
                         "max_abs_fractional_A3_change_vs_power2"])
        for scenario in SCENARIOS:
            select = d["scenario"]==scenario
            nominal = thresholds[2.0][select]
            for power,all_values in thresholds.items():
                values = all_values[select]
                writer.writerow([scenario,power,len(values),np.median(values),
                                 np.count_nonzero(values<=100),np.max(abs(values/nominal-1))])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalogue", type=Path)
    parser.add_argument("--lisa-code", type=Path)
    parser.add_argument("--input", type=Path, default=DATA/"lisa_slow_input.npz")
    parser.add_argument("--output", type=Path, default=DATA/"inner_slow_extrapolation.csv")
    args = parser.parse_args()
    if args.catalogue is not None or args.lisa_code is not None:
        if not (args.catalogue and args.lisa_code):
            parser.error("Rebuilding the input requires both --catalogue and --lisa-code.")
        make_fixture(args.catalogue,args.lisa_code,args.input)
    run(args.input,args.output)
