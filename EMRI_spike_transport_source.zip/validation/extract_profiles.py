"""Extract the histories and fixed-count means plotted in the manuscript.

Usage: python extract_profiles.py PROJECT_ROOT. Keep the resulting tables beside
the manuscript for figure-only reproduction without the numerical archive.
"""
import csv
import gzip
import sys
from pathlib import Path

root = Path(sys.argv[1])
base = root / 'emri_population_work' / 'profiles'
output = Path(__file__).resolve().parents[1] / 'data'
fields = ['host','population','history','N','shell','r_mid','rho0','rho','survival']
with gzip.open(output / 'plotted_histories.csv.gz', 'wt', newline='') as sink:
    writer = csv.DictWriter(sink, fieldnames=fields)
    writer.writeheader()
    for host in ('gc','low'):
        for population in ('catalogue','maintained'):
            if population == 'catalogue':
                folder, model = base/'catalogue', 'Best'
            elif host == 'gc':
                folder, model = base/'tail_completion'/'support_completion', 'FV_empty_support'
            else:
                folder, model = base/'tail_completion', 'FV_tail'
            with (folder/f'histories_{host}.csv').open() as source:
                rows = [r for r in csv.DictReader(source) if r['model']==model and r['scenario']=='central']
            assert len(rows)==100*17 and len({r['history'] for r in rows})==100
            for r in rows:
                r['population']=population
                writer.writerow({k:r[k] for k in fields})
fields = ['host','model','r_mid','rho0','rho','survival']
with (output / 'fixed_count_profiles.csv').open('w',newline='') as sink:
    writer=csv.DictWriter(sink,fieldnames=fields)
    writer.writeheader()
    for host in ('gc','low'):
        with (base/'catalogue'/f'mean_profiles_{host}.csv').open() as source:
            rows = [r for r in csv.DictReader(source) if r['history_law']=='fixed_N' and float(r['count_parameter'])==270 and r['model'] in ('Best','Finite_volume_burst','Direct_first_passage','Rom','Babak')]
        assert len(rows)==5*17
        for r in rows:
            writer.writerow({k:r[k] for k in fields})
