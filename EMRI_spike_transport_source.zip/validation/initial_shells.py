"""Compare the seed orbital projection with shell-averaged local four-momentum integrals.

Run from any directory. The two arguments locate the shipped emri_research_work
and regime directories. Each profile receives its own log-interpolated 100-rg
anchor, as in the published density comparison.
"""
import argparse
from pathlib import Path
import sys

import numpy as np
from numpy.polynomial.legendre import leggauss


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("research", type=Path)
    parser.add_argument("regime", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    sys.path.insert(0, str(args.regime.resolve()))
    sys.path.insert(0, str(args.research.resolve() / "verification"))
    from initial_profile import density_at_radius

    projection = np.load(args.research / "profiles" / "projection_fine.npz")
    radii = projection["r"]
    edges = projection["edges"]
    orbital_density = projection["rho0"]
    log_radii = np.log(radii)
    anchor = np.log(100.0)
    columns = [radii, orbital_density / np.exp(np.interp(anchor, log_radii, np.log(orbital_density)))]
    for radial_order, momentum_order in [(5, 30), (7, 44)]:
        nodes, weights = leggauss(radial_order)
        density = []
        for lower, upper in zip(edges[:-1], edges[1:]):
            r = (upper + lower) / 2 + nodes * (upper - lower) / 2
            volume_weight = weights * r**2 / np.sqrt(1 - 2/r)
            local = [density_at_radius(x, momentum_order)[0] for x in r]
            density.append(np.average(local, weights=volume_weight))
        density = np.asarray(density)
        density /= np.exp(np.interp(anchor, log_radii, np.log(density)))
        columns.extend([density, columns[1] / density - 1])
    header = ("r_rg,orbital_normalized,local_5x30_normalized,relative_difference_5x30,"
              "local_7x44_normalized,relative_difference_7x44")
    np.savetxt(args.out, np.column_stack(columns), delimiter=",", header=header, comments="")


if __name__ == "__main__":
    main()
