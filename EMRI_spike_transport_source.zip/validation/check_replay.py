"""Check a fresh endpoint reconstruction and any available manuscript controls."""
import argparse
import csv
from pathlib import Path

import numpy as np


def check_csv(reference, result):
    with reference.open() as f, result.open() as g:
        left, right = csv.DictReader(f), csv.DictReader(g)
        if left.fieldnames != right.fieldnames:
            raise ValueError(f'{result}: different column labels')
        keys = left.fieldnames
        left, right = list(left), list(right)
    if len(left) != len(right):
        raise ValueError(f'{result}: different row count')
    for key in keys:
        a = [row[key] for row in left]
        b = [row[key] for row in right]
        try:
            a, b = np.array(a, dtype=float), np.array(b, dtype=float)
        except ValueError:
            if a != b:
                raise ValueError(f'{result}: different labels in {key}')
            continue
        np.testing.assert_allclose(a, b, rtol=2e-10, atol=1e-11,
                                   equal_nan=True, err_msg=f'{result}, {key}')
    print(f'{reference.name}: {len(left)} rows agree')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--reference', type=Path,
                        default=Path(__file__).resolve().parents[1]/'data')
    parser.add_argument('--table', help='Compare just this CSV, independently of the endpoint replay.')
    args = parser.parse_args()
    if args.table is not None:
        check_csv(args.reference/args.table,args.output/args.table)
        raise SystemExit(0)
    for name in ['endpoint_budget.csv','endpoint_domain_mass.csv','initial_shells.csv',
                 'frozen_comparison.csv','binary_validation.csv','inner_slow_extrapolation.csv',
                 'overlapping_inspirals.csv']:
        path = args.output/name
        if path.is_file() or name.startswith('endpoint_'):
            check_csv(args.reference/name,path)
    name = 'endpoint_cells.npz'
    with np.load(args.reference/name) as left, np.load(args.output/name) as right:
        if set(left.files) != set(right.files):
            raise ValueError(f'{name}: array labels differ')
        for key in left:
            np.testing.assert_allclose(left[key],right[key],rtol=2e-10,atol=1e-14,
                                       err_msg=f'{name}, {key}')
    print(f'{name}: all cell arrays agree')
